# Airport Weather Analytics

Static, client-side web app (vanilla JS + inline SVG, no build dependencies). Chosen so it runs anywhere, keeps uploaded data in the browser, and has nothing to host server-side. Optional XLSX support loads SheetJS from cdnjs.

## Run
    node build.js            # writes dist/ (index.html, manifest, sw.js, icon)
    npx serve dist           # or: python3 -m http.server -d dist  → open http://localhost:3000
    node --test test/calc.test.js    # tests (set DATA=/path/file.csv for the integration test)

## Load data
Import tab → choose a CSV/XLSX/JSON file (or a URL if the host allows CORS) → confirm column mapping and units → Validate & load.
Data stays in browser memory only; nothing is uploaded or saved. Reloading clears it.

## Deploy
Upload the contents of `dist/` to any static host (Netlify, GitHub Pages, Cloudflare Pages, S3). HTTPS is required for the PWA.
Install on a phone: open the site → Share/⋮ menu → "Add to Home Screen". Install on desktop: browser address-bar install icon.

## Layout
`src/calc.js` parsing + statistics (tested) · `src/app.template.html` UI · `build.js` inlines calc into one page.
